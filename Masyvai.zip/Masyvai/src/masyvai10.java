import java.util.Arrays;
import java.util.Scanner;

public class masyvai10 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int number = rd.nextInt();

        System.out.println("Iveskite intervalo pradzia:");
        int min = rd.nextInt();

        System.out.println("Iveskite intervalo pabaiga:");
        int max = rd.nextInt();

        max++;

        int kiek = 0;

        int [] arrA = new int [number];

        for (int i = 0; i < arrA.length; i++) {
            arrA [i] = random (min, max);
        }

        for (int i = 0; i < arrA.length; i++) {
            if (arrA [i] == 0){
                kiek++;
            }
        }

        System.out.println("arrA masyve yra " + kiek + " elementai, kuriu reiksme lygi 0. ");
        System.out.print(Arrays.toString(arrA));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}