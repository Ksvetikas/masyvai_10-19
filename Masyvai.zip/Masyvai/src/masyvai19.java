import java.util.Arrays;
import java.util.Scanner;

public class masyvai19 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int n = rd.nextInt();

        int min = -1000;

        int max = 1000;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] arrZ = new int [n];

        int minArrZ = 0;
        int maxArrZ = 0;
        int minArrZEilNr = 1;
        int maxArrZEilNr = 1;

        for (int i = 0 ; i < arrZ.length; i++) {

            arrZ [i] = random (min, max);
            if (i == 0){
                minArrZ = arrZ [i];
                maxArrZ = arrZ [i];
                minArrZEilNr = 1;
                maxArrZEilNr = 1;

            }else if (minArrZ > arrZ [i]) {
                minArrZ = arrZ [i];
                minArrZEilNr = i + 1;

            }else if (maxArrZ < arrZ [i]) {
                maxArrZ = arrZ [i];
                maxArrZEilNr = i + 1;
            }
        }

        System.out.print("Maziausias masyve yra ");
        int countmin = 0;

        for (int i = 0 ; i < arrZ.length; i++) {
            if (minArrZ == arrZ [i]) {
                countmin++;
            }
        }

        if (countmin == 1) {
            System.out.print(minArrZEilNr + " ");

        }else if (countmin > 1) {

            for (int i = 0 ; i < arrZ.length; i++){
                if (minArrZ == arrZ [i]) {
                    System.out.print((i + 1) + ", ");
                }
            }
        }

        System.out.println("masyvo elementas, jo reiksme yra " + minArrZ + ".");


        System.out.print("Didziausias masyve yra ");

        int countmax = 0;

        for (int i = 0 ; i < arrZ.length; i++) {
            if (maxArrZ == arrZ [i]) {
                countmax++;
            }
        }

        if (countmax == 1) {
            System.out.print(maxArrZEilNr + " ");

        }else if (countmax > 1) {

            for (int i = 0 ; i < arrZ.length; i++){
                if (maxArrZ == arrZ [i]) {
                    System.out.print((i + 1) + ", ");
                }
            }
        }


        System.out.println("masyvo elementas, jo reiksme yra " + maxArrZ + ".");
        System.out.println("Visas masyvas: ");
        System.out.print(Arrays.toString(arrZ));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}