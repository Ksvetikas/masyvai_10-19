import java.util.Arrays;
import java.util.Scanner;

public class masyvai13 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int number = rd.nextInt();

        int min = -1000;

        int max = 1000;

        max++;

        int kiekTeigiamu = 0;

        int [] arrD = new int [number];

        for (int i = 0; i < arrD.length; i++) {
            arrD [i] = random (min, max);
            if (arrD [i] > 0){
                kiekTeigiamu++;
            }
        }

        int [] arrE = new int [kiekTeigiamu];

        for (int i = 0; i < arrE.length; ) {
            for (int j = 0; j < arrD.length; j++) {
                if (arrD [j] > 0){
                    arrE [i] = arrD [j];
                    i++;
                }
            }
         }



        System.out.println("arrE masyvas sudarytas is " + kiekTeigiamu + " elementu ,kuriu reiksmes yra teigiamos arrD masyvo reiksmes.");
        System.out.print(Arrays.toString(arrE));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}