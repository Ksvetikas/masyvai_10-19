import java.util.Arrays;
import java.util.Scanner;

public class masyvai11 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int number = rd.nextInt();

        int min = 0;

        int max = 1000;

        max++;

        int kiek = 0;

        int skaiciuSuma = 0;

        int [] arrB = new int [number];

        for (int i = 0; i < arrB.length; i++) {
            arrB [i] = random (min, max);
        }

        for (int i = 0; i < arrB.length; i++) {
            if (arrB [i] == 0){
                continue;
            }
            if (arrB [i] % 3 == 0){
                kiek++;
                skaiciuSuma = skaiciuSuma + arrB [i];
            }
        }

        System.out.println("arrb masyve yra " + kiek + " elementu daliu is 3, ju suma lygi " + skaiciuSuma + ".");
        System.out.print(Arrays.toString(arrB));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}